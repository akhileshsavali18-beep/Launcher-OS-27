package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppRepository
import com.example.model.AppCategory
import com.example.model.AppModel
import com.example.model.BatteryState
import com.example.model.QuickToggleState
import com.example.model.WeatherState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LauncherUiState(
  val installedApps: List<AppModel> = emptyList(),
  val dockApps: List<AppModel> = emptyList(),
  val homeApps: List<AppModel> = emptyList(),
  val searchQuery: String = "",
  val timeString: String = "9:41",
  val dateString: String = "Sunday, Sep 20",
  val dayString: String = "Sunday",
  val batteryState: BatteryState = BatteryState(),
  val weatherState: WeatherState = WeatherState(),
  val quickToggles: QuickToggleState = QuickToggleState(),
  val isLoading: Boolean = true,
  val feedbackMessage: String? = null
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = AppRepository(application)

  // StateFlow holding the list of installed applications
  private val _installedApps = MutableStateFlow<List<AppModel>>(emptyList())
  val installedApps: StateFlow<List<AppModel>> = _installedApps.asStateFlow()

  private val _uiState = MutableStateFlow(LauncherUiState())
  val uiState: StateFlow<LauncherUiState> = _uiState.asStateFlow()

  init {
    loadApps()
    startTimeUpdates()
    updateBatteryStatus()
  }

  fun refreshApps() {
    loadApps()
  }

  private fun loadApps() {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true) }
      
      // Query real installed apps via PackageManager
      val realApps = repository.loadInstalledApps().map { appInfo ->
        AppModel(
          appName = appInfo.label,
          packageName = appInfo.packageName,
          icon = appInfo.iconBitmap,
          activityName = appInfo.activityName,
          category = appInfo.category
        )
      }

      // Fallback to mock data for preview/testing environments if no real packages found
      val apps = if (realApps.isEmpty()) {
        getMockApps()
      } else {
        realApps
      }

      _installedApps.value = apps

      // Identify Dock apps (Phone, Messages, Browser, Camera or first available)
      val dockApps = selectDockApps(apps)
      val homeApps = apps.filterNot { dockApps.contains(it) }

      _uiState.update {
        it.copy(
          installedApps = apps,
          dockApps = dockApps,
          homeApps = homeApps,
          isLoading = false
        )
      }
    }
  }

  private fun getMockApps(): List<AppModel> {
    return listOf(
      AppModel("Phone", "com.android.dialer", null, "", AppCategory.SOCIAL),
      AppModel("Messages", "com.android.messaging", null, "", AppCategory.SOCIAL),
      AppModel("Chrome", "com.android.chrome", null, "", AppCategory.UTILITIES),
      AppModel("Camera", "com.android.camera2", null, "", AppCategory.CREATIVE),
      AppModel("Photos", "com.google.android.apps.photos", null, "", AppCategory.CREATIVE),
      AppModel("Calendar", "com.google.android.calendar", null, "", AppCategory.PRODUCTIVITY),
      AppModel("Notes", "com.apple.notes", null, "", AppCategory.PRODUCTIVITY),
      AppModel("Spotify", "com.spotify.music", null, "", AppCategory.ENTERTAINMENT),
      AppModel("YouTube", "com.google.android.youtube", null, "", AppCategory.ENTERTAINMENT),
      AppModel("Settings", "com.android.settings", null, "", AppCategory.SYSTEM)
    )
  }

  private fun selectDockApps(apps: List<AppModel>): List<AppModel> {
    val dockList = mutableListOf<AppModel>()

    apps.find { it.packageName.contains("dialer") || it.packageName.contains("phone") || it.appName.contains("Phone", ignoreCase = true) }
      ?.let { dockList.add(it) }

    apps.find { !dockList.contains(it) && (it.packageName.contains("messaging") || it.packageName.contains("mms") || it.appName.contains("Messages", ignoreCase = true)) }
      ?.let { dockList.add(it) }

    apps.find { !dockList.contains(it) && (it.packageName.contains("chrome") || it.packageName.contains("browser") || it.appName.contains("Chrome", ignoreCase = true)) }
      ?.let { dockList.add(it) }

    apps.find { !dockList.contains(it) && (it.packageName.contains("camera") || it.appName.contains("Camera", ignoreCase = true)) }
      ?.let { dockList.add(it) }

    if (dockList.size < 4) {
      for (app in apps) {
        if (!dockList.contains(app)) {
          dockList.add(app)
        }
        if (dockList.size == 4) break
      }
    }

    return dockList
  }

  private fun startTimeUpdates() {
    viewModelScope.launch {
      val timeFormat = SimpleDateFormat("h:mm", Locale.getDefault())
      val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
      val dayFormat = SimpleDateFormat("EEEE", Locale.getDefault())

      while (isActive) {
        val now = Date()
        _uiState.update {
          it.copy(
            timeString = timeFormat.format(now),
            dateString = dateFormat.format(now),
            dayString = dayFormat.format(now)
          )
        }
        delay(1000L)
      }
    }
  }

  fun updateBatteryStatus() {
    val battery = repository.getBatteryStatus()
    _uiState.update { it.copy(batteryState = battery) }
  }

  fun onSearchQueryChanged(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun launchApp(app: AppModel) {
    val success = repository.launchApp(app)
    if (!success) {
      _uiState.update { it.copy(feedbackMessage = "Could not open ${app.appName}") }
    }
  }

  fun openSettings() {
    repository.openSystemSettings()
  }

  fun openWifiSettings() {
    repository.openWifiSettings()
  }

  fun openBluetoothSettings() {
    repository.openBluetoothSettings()
  }

  fun toggleWifi() {
    _uiState.update {
      it.copy(quickToggles = it.quickToggles.copy(isWifiEnabled = !it.quickToggles.isWifiEnabled))
    }
  }

  fun toggleBluetooth() {
    _uiState.update {
      it.copy(quickToggles = it.quickToggles.copy(isBluetoothEnabled = !it.quickToggles.isBluetoothEnabled))
    }
  }

  fun toggleFlashlight() {
    _uiState.update {
      it.copy(quickToggles = it.quickToggles.copy(isFlashlightOn = !it.quickToggles.isFlashlightOn))
    }
  }

  fun toggleAirplane() {
    _uiState.update {
      it.copy(quickToggles = it.quickToggles.copy(isAirplaneMode = !it.quickToggles.isAirplaneMode))
    }
  }

  fun clearFeedbackMessage() {
    _uiState.update { it.copy(feedbackMessage = null) }
  }
}
