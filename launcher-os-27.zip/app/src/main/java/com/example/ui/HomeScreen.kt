package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppInfo
import com.example.ui.components.AppIconItem
import com.example.ui.components.AppLibrarySheet
import com.example.ui.components.BatteryWidget
import com.example.ui.components.ClockWidget
import com.example.ui.components.ControlCenterWidget
import com.example.ui.components.BottomDock
import com.example.ui.components.GlassCard
import com.example.ui.components.TopStatusBar
import com.example.ui.components.WeatherWidget
import com.example.ui.theme.CupertinoBlue
import com.example.ui.theme.CupertinoGreen
import com.example.ui.theme.CupertinoOrange
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassWhiteHigh
import com.example.ui.theme.GlassWhiteMedium
import com.example.ui.theme.WallpaperCyanGlow
import com.example.ui.theme.WallpaperDarkNavy
import com.example.ui.theme.WallpaperDeepIndigo
import com.example.ui.theme.WallpaperSunsetMagenta
import com.example.ui.theme.WallpaperVibrantViolet
import com.example.viewmodel.LauncherViewModel
import kotlinx.coroutines.launch

/**
 * Main Launcher OS 18 Screen featuring iOS 18 glassmorphism, widgets, home grid, and app library.
 */
@Composable
fun HomeScreen(
  viewModel: LauncherViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val pagerState = rememberPagerState(initialPage = 1, pageCount = { 3 })
  val coroutineScope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(uiState.feedbackMessage) {
    uiState.feedbackMessage?.let { message ->
      snackbarHostState.showSnackbar(message)
      viewModel.clearFeedbackMessage()
    }
  }

  // Background iOS 18 Mesh Gradient
  val wallpaperBrush = Brush.verticalGradient(
    colors = listOf(
      WallpaperDarkNavy,
      WallpaperDeepIndigo,
      WallpaperVibrantViolet,
      WallpaperSunsetMagenta.copy(alpha = 0.85f),
      WallpaperCyanGlow.copy(alpha = 0.5f),
      WallpaperDarkNavy
    )
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(wallpaperBrush)
  ) {
    Column(
      modifier = Modifier.fillMaxSize()
    ) {
      // Top Status Bar & Dynamic Island
      TopStatusBar(
        timeString = uiState.timeString,
        battery = uiState.batteryState,
        appCount = uiState.installedApps.size
      )

      // Main Horizontal Pager for Home Pages
      HorizontalPager(
        state = pagerState,
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
      ) { pageIndex ->
        when (pageIndex) {
          0 -> WidgetsPage(
            uiState = uiState,
            onOpenSettings = { viewModel.openSettings() },
            onToggleWifi = { viewModel.toggleWifi() },
            onToggleBluetooth = { viewModel.toggleBluetooth() },
            onToggleFlashlight = { viewModel.toggleFlashlight() },
            onToggleAirplane = { viewModel.toggleAirplane() }
          )
          1 -> HomeGridPage(
            uiState = uiState,
            onAppClick = { viewModel.launchApp(it) },
            onOpenClock = { viewModel.openSettings() },
            onOpenWeather = { viewModel.openSettings() }
          )
          2 -> AppLibrarySheet(
            apps = uiState.installedApps,
            searchQuery = uiState.searchQuery,
            onSearchQueryChange = { viewModel.onSearchQueryChanged(it) },
            onAppClick = { viewModel.launchApp(it) }
          )
        }
      }

      // Page Indicator Dots
      PageIndicators(
        pageCount = 3,
        currentPage = pagerState.currentPage,
        onDotClick = { page ->
          coroutineScope.launch { pagerState.animateScrollToPage(page) }
        },
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp)
      )

      // Frosted Glass Bottom Dock
      BottomDock(
        dockApps = uiState.dockApps,
        onAppClick = { viewModel.launchApp(it) },
        modifier = Modifier
          .navigationBarsPadding()
          .padding(bottom = 12.dp)
      )
    }

    // Snackbar Host
    SnackbarHost(
      hostState = snackbarHostState,
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 110.dp)
    )

    // Loading indicator on first launch
    AnimatedVisibility(
      visible = uiState.isLoading,
      enter = fadeIn(),
      exit = fadeOut(),
      modifier = Modifier.align(Alignment.Center)
    ) {
      GlassCard(
        modifier = Modifier.padding(24.dp),
        backgroundColor = GlassWhiteHigh
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          CircularProgressIndicator(
            color = CupertinoBlue,
            strokeWidth = 3.dp,
            modifier = Modifier.size(36.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Loading Launcher OS 18...",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }
  }
}

/**
 * Page 0: Glassmorphic Widgets Dashboard.
 */
@Composable
private fun WidgetsPage(
  uiState: com.example.viewmodel.LauncherUiState,
  onOpenSettings: () -> Unit,
  onToggleWifi: () -> Unit,
  onToggleBluetooth: () -> Unit,
  onToggleFlashlight: () -> Unit,
  onToggleAirplane: () -> Unit
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .testTag("widgets_page"),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Clock Widget
    ClockWidget(
      timeString = uiState.timeString,
      dateString = uiState.dateString,
      dayString = uiState.dayString,
      onClick = onOpenSettings
    )

    // Dual Column: Weather and Battery
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      WeatherWidget(
        weather = uiState.weatherState,
        modifier = Modifier.weight(1f),
        onClick = onOpenSettings
      )
      BatteryWidget(
        battery = uiState.batteryState,
        modifier = Modifier.weight(1f),
        onClick = onOpenSettings
      )
    }

    // Control Center Quick Toggles Widget
    ControlCenterWidget(
      toggleState = uiState.quickToggles,
      onToggleWifi = onToggleWifi,
      onToggleBluetooth = onToggleBluetooth,
      onToggleFlashlight = onToggleFlashlight,
      onToggleAirplane = onToggleAirplane,
      onOpenSettings = onOpenSettings
    )

    Spacer(modifier = Modifier.height(20.dp))
  }
}

/**
 * Page 1: Main Home Screen with top widgets and 4-column app grid.
 */
@Composable
private fun HomeGridPage(
  uiState: com.example.viewmodel.LauncherUiState,
  onAppClick: (AppInfo) -> Unit,
  onOpenClock: () -> Unit,
  onOpenWeather: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("home_grid_page")
  ) {
    // Top Compact Glance Widgets: Clock & Weather Side-by-Side
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      GlassCard(
        modifier = Modifier
          .weight(1f)
          .height(84.dp),
        backgroundColor = GlassWhiteMedium,
        shape = RoundedCornerShape(22.dp),
        onClick = onOpenClock
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = uiState.dayString.uppercase(),
            color = CupertinoOrange,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
          Text(
            text = uiState.timeString,
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      GlassCard(
        modifier = Modifier
          .weight(1f)
          .height(84.dp),
        backgroundColor = GlassWhiteMedium,
        shape = RoundedCornerShape(22.dp),
        onClick = onOpenWeather
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = uiState.weatherState.location,
              color = Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
            Text(
              text = "${uiState.weatherState.temperatureCelsius}°",
              color = Color.White,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Text(
            text = uiState.weatherState.condition,
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 11.sp
          )
        }
      }
    }

    // 4-Column iOS Style App Grid
    LazyVerticalGrid(
      columns = GridCells.Fixed(4),
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      items(uiState.homeApps, key = { it.packageName + it.activityName }) { app ->
        AppIconItem(
          app = app,
          iconSize = 58.dp,
          showLabel = true,
          onClick = { onAppClick(app) }
        )
      }
    }
  }
}

/**
 * iOS 18 Page Indicators with active capsule indicator.
 */
@Composable
private fun PageIndicators(
  pageCount: Int,
  currentPage: Int,
  onDotClick: (Int) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically
  ) {
    repeat(pageCount) { index ->
      val isSelected = index == currentPage
      Box(
        modifier = Modifier
          .padding(horizontal = 4.dp)
          .size(
            width = if (isSelected) 18.dp else 7.dp,
            height = 7.dp
          )
          .clip(if (isSelected) RoundedCornerShape(4.dp) else CircleShape)
          .background(
            if (isSelected) Color.White else Color.White.copy(alpha = 0.35f)
          )
          .clickable { onDotClick(index) }
      )
    }
  }
}
