package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.model.AppInfo
import com.example.ui.theme.CupertinoBlue
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassWhiteHigh
import com.example.ui.theme.GlassWhiteLow
import com.example.ui.theme.GlassWhiteMedium

/**
 * iOS 18 App Library Screen with Glassmorphic Categorized Cluster Folders and Search.
 */
@Composable
fun AppLibrarySheet(
  apps: List<AppInfo>,
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  onAppClick: (AppInfo) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("app_library_screen")
  ) {
    // Search Bar
    GlassSearchBar(
      query = searchQuery,
      onQueryChange = onSearchQueryChange,
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp)
    )

    if (searchQuery.isNotBlank()) {
      // Filtered Results List
      val filteredApps = apps.filter {
        it.label.contains(searchQuery, ignoreCase = true) ||
          it.packageName.contains(searchQuery, ignoreCase = true)
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 120.dp)
      ) {
        if (filteredApps.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "No apps found for \"$searchQuery\"",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 15.sp
              )
            }
          }
        } else {
          items(filteredApps, key = { it.packageName }) { app ->
            GlassCard(
              modifier = Modifier.fillMaxWidth(),
              backgroundColor = GlassWhiteLow,
              shape = RoundedCornerShape(18.dp),
              onClick = { onAppClick(app) }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                AppIconItem(
                  app = app,
                  iconSize = 48.dp,
                  showLabel = false,
                  onClick = { onAppClick(app) }
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                  Text(
                    text = app.label,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  Text(
                    text = app.category.title,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp
                  )
                }
              }
            }
          }
        }
      }
    } else {
      // Categorized Folders Grid (iOS 18 App Library 2x2 cluster cards)
      val categories = AppCategory.values()
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 120.dp)
      ) {
        items(categories) { category ->
          val categoryApps = apps.filter { it.category == category }
          if (categoryApps.isNotEmpty()) {
            CategoryClusterCard(
              category = category,
              apps = categoryApps,
              onAppClick = onAppClick
            )
          }
        }
      }
    }
  }
}

/**
 * iOS 18 2x2 App Library Category Card.
 */
@Composable
fun CategoryClusterCard(
  category: AppCategory,
  apps: List<AppInfo>,
  onAppClick: (AppInfo) -> Unit,
  modifier: Modifier = Modifier
) {
  GlassCard(
    modifier = modifier
      .height(178.dp)
      .fillMaxWidth(),
    backgroundColor = GlassWhiteMedium,
    shape = RoundedCornerShape(26.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(12.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // 2x2 Grid inside the category card
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        if (apps.isNotEmpty()) {
          AppIconItem(app = apps[0], iconSize = 46.dp, showLabel = false, onClick = { onAppClick(apps[0]) })
        }
        if (apps.size > 1) {
          AppIconItem(app = apps[1], iconSize = 46.dp, showLabel = false, onClick = { onAppClick(apps[1]) })
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        if (apps.size > 2) {
          AppIconItem(app = apps[2], iconSize = 46.dp, showLabel = false, onClick = { onAppClick(apps[2]) })
        }
        if (apps.size > 3) {
          // 4th slot: mini 2x2 folder cluster icon
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(Color.White.copy(alpha = 0.15f))
              .clickable { onAppClick(apps[3]) },
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Folder,
              contentDescription = "More apps in folder",
              tint = Color.White.copy(alpha = 0.85f),
              modifier = Modifier.size(24.dp)
            )
          }
        }
      }

      Text(
        text = category.title,
        color = Color.White.copy(alpha = 0.9f),
        fontSize = 11.5.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        modifier = Modifier.padding(top = 4.dp)
      )
    }
  }
}

/**
 * Glass Search Bar in iOS 18 style.
 */
@Composable
fun GlassSearchBar(
  query: String,
  onQueryChange: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .height(48.dp)
      .clip(RoundedCornerShape(24.dp))
      .background(GlassWhiteHigh)
      .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
      .padding(horizontal = 14.dp),
    contentAlignment = Alignment.CenterStart
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Default.Search,
        contentDescription = "Search apps",
        tint = Color.White.copy(alpha = 0.7f),
        modifier = Modifier.size(20.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Box(modifier = Modifier.weight(1f)) {
        if (query.isEmpty()) {
          Text(
            text = "App Library",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 15.sp
          )
        }
        BasicTextField(
          value = query,
          onValueChange = onQueryChange,
          textStyle = TextStyle(
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
          ),
          cursorBrush = SolidColor(CupertinoBlue),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("app_search_input")
        )
      }
      if (query.isNotEmpty()) {
        Box(
          modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.25f))
            .clickable { onQueryChange("") },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Clear,
            contentDescription = "Clear search",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }
  }
}
