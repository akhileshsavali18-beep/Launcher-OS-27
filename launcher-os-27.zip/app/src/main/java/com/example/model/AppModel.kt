package com.example.model

import androidx.compose.ui.graphics.ImageBitmap

/**
 * Categorization for iOS 18 style App Library clusters.
 */
enum class AppCategory(val title: String) {
  SUGGESTIONS("Suggestions"),
  SOCIAL("Social & Communication"),
  UTILITIES("Utilities"),
  PRODUCTIVITY("Productivity & Finance"),
  ENTERTAINMENT("Entertainment"),
  CREATIVE("Creativity & Media"),
  SYSTEM("System & Tools")
}

/**
 * Data class representing an application model with appName, packageName, and icon.
 */
data class AppModel(
  val appName: String,
  val packageName: String,
  val icon: ImageBitmap? = null,
  val activityName: String = "",
  val category: AppCategory = AppCategory.UTILITIES,
  val isSystemApp: Boolean = false,
  val installTime: Long = 0L
) {
  val label: String get() = appName
  val iconBitmap: ImageBitmap? get() = icon
}

typealias AppInfo = AppModel

/**
 * Live weather state for iOS 18 weather widget.
 */
data class WeatherState(
  val location: String = "Cupertino",
  val temperatureCelsius: Int = 22,
  val condition: String = "Mostly Sunny",
  val highTemp: Int = 26,
  val lowTemp: Int = 16,
  val uvIndex: Int = 4,
  val windSpeedKmh: Int = 14
)

/**
 * Battery and system state for iOS 18 power widget.
 */
data class BatteryState(
  val percentage: Int = 94,
  val isCharging: Boolean = false,
  val powerSaveMode: Boolean = false
)

/**
 * Quick toggle state for Control Center widget.
 */
data class QuickToggleState(
  val isWifiEnabled: Boolean = true,
  val isBluetoothEnabled: Boolean = true,
  val isFlashlightOn: Boolean = false,
  val isAirplaneMode: Boolean = false,
  val isDoNotDisturb: Boolean = false,
  val isHotspotOn: Boolean = false
)
